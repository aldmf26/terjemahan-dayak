<?php return array (
  'form' => 'App\\Http\\Livewire\\Form',
);