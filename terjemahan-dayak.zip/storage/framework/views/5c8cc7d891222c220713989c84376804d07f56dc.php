<table id="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Indonesia</th>
            <th>Dayak</th>
            <?php if(auth()->guard()->check()): ?>
            <th style="text-align: center">Aksi</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php
            $tbl = DB::table('tb_terjemahan')->orderBy('id', 'DESC')->get();
        ?>
        <?php $__currentLoopData = $tbl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td width="5%"><?php echo e($no+1); ?></td>
                <td><?php echo e($d->indonesia); ?></td>
                <td><?php echo e($d->dayak); ?></td>
                <?php if(auth()->guard()->check()): ?>
                <td align="center">
                    <button class="btn btn-xs"><i class="fas fa-pen"></i></button>
                    <a id="<?php echo e($d->id); ?>" class="btn btn-xs deleteRow"><i class="fas fa-trash"></i></a>
                </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH G:\PROGRAMMER\LARAVEL 9\terjemahan-dayak\resources\views/admin/loadTabel.blade.php ENDPATH**/ ?>